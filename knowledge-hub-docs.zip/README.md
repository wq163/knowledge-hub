# Knowledge Hub — 0.1 prototype

个人跨 Agent 会话归档工具。Node.js 22.13+，使用内置 SQLite，无 npm 运行依赖。

```sh
npm test
npm run hub -- scan codex
npm run hub -- scan claude
npm run hub -- scan pi
npm run hub -- import chatgpt /path/to/conversations.json
npm run hub -- search '知识库'
npm run hub -- show <key>
```

`HUB_DATA_DIR` 可设置独立数据目录，默认 `~/.local/share/knowledge-hub`。建议 `umask 077` 后运行，数据可能包含隐私和凭证，不要将数据目录提交 Git。扫描目录可作为第二个参数传入，多账号需明确传入独立 account。首次测试使用备份文件而非生产会话。

## 已实现

- 本地 JSONL 基础解析：Codex、Claude Code、Pi；ChatGPT 导出 conversations.json 的当前分支解析。
- 原始文件内容寻址备份、统一会话存储、重复导入检查、原始快照关联、SQLite FTS5 trigram 检索。
- CLI 查询、显式扫描及导入。采集过程不调用模型。

## 限制与下一阶段

原型仅使用合成测试数据，真实版本/格式需现场校验。当前统一索引只包含文本消息，完整工具调用、分支和附件元数据仍留在原始文件（外部附件本体未采集）。扫描按文件全量读取，原始版本按内容哈希去重；尚无跨机器同步、时间排序防止旧导出覆盖、DeepSeek 导入或云端自动同步。并发写入、磁盘权限、错误恢复等仍需生产化测试。

后续拆分三个阶段：Collector -> Conversation Store；Extractor 按会话版本记录独立检查点并输出候选知识；Organizer 定时检索 Vault 并在受限写入范围内合并，来源可追溯，Git 回滚，人工编辑冲突检查。候选池不等于正式知识库。避免把原始会话直接放到 Vault。默认不向外部模型发送原始会话；知识处理需显式配置模型、数据范围和敏感信息策略。
